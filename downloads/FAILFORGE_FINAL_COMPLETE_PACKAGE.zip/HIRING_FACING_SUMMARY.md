# FAILFORGE — Hiring-Facing Summary

## One-liner

I built FAILFORGE, a failure-conditioned synthetic RL framework for computer-use agents where verified execution failures generate the next training distribution.

## Why it matters for Computer Use

The project directly targets:
- multimodal computer-use perception;
- long-horizon RL;
- sparse reward;
- synthetic RL environments;
- trajectory-aware evaluation;
- reward hacking and shortcut detection;
- recovery from dynamic UI state;
- benchmark/evaluation infrastructure.

## Executed evidence

- Symbolic computer-use benchmark: completed.
- Visual screenshot-based benchmark: completed.
- BrowserGym/MiniWoB bridge: implemented and mock-tested.
- Public MiniWoB score: not claimed due to runtime installation limits.

## Main visual result

FAILFORGE-HardMine improved combined visual OOD accuracy over UniformFactor-RL:

- UniformFactor-RL: 43.3%
- FAILFORGE-HardMine: 49.2%
- Gain: +5.9 pp
- 4/4 matched seeds positive
- paired p=0.0334

## Strongest safety/eval result

Removing trajectory-aware reward correction increased visual shortcut behavior from
0.1% to 27.4%.

## Mature scientific positioning

The project explicitly retains negative results:
- sparse visual RL collapses from scratch;
- category-level failure reweighting is insufficient;
- hard-mining ratio is non-monotonic;
- local competence does not solve long-horizon completion.

That makes the work credible rather than overclaimed.
