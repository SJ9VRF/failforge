# FAILFORGE Final Package

## Main documents

- `FAILFORGE_paper_submission_draft.md`
- `BENCHMARK_CARD.md`
- `STATISTICAL_ROBUSTNESS_REPORT.md`
- `FAILURE_ANALYSIS_ATLAS.md`
- `ALGORITHM_SECTION.md`
- `REVIEWER_ATTACK_AND_RESPONSE.md`
- `REPRODUCIBILITY_STATEMENT.md`
- `HIRING_FACING_SUMMARY.md`
- `manifest.json`
- `run_all.sh`

## Webpage

- `project_webpage/index.html`

## Included prior work

- `failforge_package/` — symbolic benchmark package
- `failforge_visual/` — visual synthetic benchmark package
- `failforge_browsergym_bridge/` — BrowserGym/MiniWoB bridge

## Integrity boundary

This package contains executed symbolic and visual synthetic results.
It does not claim OSWorld, WeaveBench, or MiniWoB public benchmark SOTA.
