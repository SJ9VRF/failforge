# FAILFORGE LaTeX Source

Compile with XeLaTeX:

```bash
xelatex main.tex
xelatex main.tex
```

The `figures/` directory contains all figures referenced by the paper.
