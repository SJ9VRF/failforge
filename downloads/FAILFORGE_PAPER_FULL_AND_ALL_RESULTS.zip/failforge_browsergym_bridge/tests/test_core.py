from failforge_bg.sampler import AdaptiveFailureSampler
from failforge_bg.failure import FailureClassifier
from failforge_bg.verifier import TrajectoryVerifier
from failforge_bg.types import Transition

def test_sampler_normalizes():
    s=AdaptiveFailureSampler(["a","b","c"])
    p=s.probabilities()
    assert abs(sum(p.values())-1)<1e-8

def test_failure_focus_increases():
    s=AdaptiveFailureSampler(["a","b"], alpha=.8,beta=.2,gamma=0, ema=0)
    s.update("a",False,1.0)
    s.update("b",True,0.0)
    assert s.probabilities()["a"] > s.probabilities()["b"]

def test_shortcut_verifier_penalizes():
    v=TrajectoryVerifier()
    clean=[Transition({}, "click()", 1, True, False, {})]
    hack=[Transition({}, "click()", 1, True, False, {"shortcut_used":True})]
    assert v.score(clean,True)[0] > v.score(hack,True)[0]

def test_classifier_detects_verification():
    c=FailureClassifier()
    ts=[Transition({}, "click()", 0, True, False, {"verification_required":True})]
    kinds={e.kind for e in c.classify("x",ts,False)}
    assert "missing_verification" in kinds
