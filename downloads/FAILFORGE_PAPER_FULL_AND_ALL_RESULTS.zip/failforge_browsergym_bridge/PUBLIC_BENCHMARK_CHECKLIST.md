# Public Benchmark Checklist

- [x] Define BrowserGym adapter.
- [x] Define task discovery.
- [x] Define task families for grounding, layout shift, long horizon, recovery,
      memory/state, manipulation, and verification.
- [x] Define failure taxonomy.
- [x] Define trajectory verifier.
- [x] Define adaptive FAILFORGE sampler.
- [x] Define seeded evaluation/logging.
- [x] Unit-test core logic independently of BrowserGym.
- [x] Attempt BrowserGym installation in current runtime.
- [ ] Install BrowserGym/MiniWoB in a network-enabled runtime.
- [ ] Install Playwright Chromium.
- [ ] Configure MiniWoB++ `MINIWOB_URL`.
- [ ] Connect the desired visual/browser policy to the Agent interface.
- [ ] Run uniform baseline on matched tasks/seeds.
- [ ] Run FAILFORGE sampler on identical tasks/seeds.
- [ ] Run verifier ablation.
- [ ] Run replay/exploration mixture ablation.
- [ ] Report public benchmark statistics.
- [ ] Only then make a MiniWoB/BrowserGym performance claim.
