import csv, json
from pathlib import Path
from failforge_bg.mock_env import MockMiniWoBEnv
from failforge_bg.agents import ScriptedInfoAgent
from failforge_bg.runner import evaluate_tasks

tasks=[
 "click-test","multi-layouts","form-sequence","login-user-popup",
 "copy-paste-2","drag-items","login-user"
]
rows=evaluate_tasks(
    lambda task,seed: MockMiniWoBEnv(task,seed),
    lambda seed: ScriptedInfoAgent(),
    tasks,
    seeds=(0,1,2,3),
    max_steps=20
)
out=Path("results/mock_bridge_results.csv")
out.parent.mkdir(exist_ok=True)
with out.open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys())
    w.writeheader(); w.writerows(rows)
print(out)
