import argparse, csv, json, sys
from pathlib import Path

from failforge_bg.browsergym_adapter import check_browsergym, list_miniwob_tasks, make_env
from failforge_bg.failure import FailureClassifier
from failforge_bg.verifier import TrajectoryVerifier
from failforge_bg.runner import run_episode
from failforge_bg.sampler import AdaptiveFailureSampler

# NOTE: BrowserGym expects executable action strings such as click(...) / fill(...).
# This harness intentionally leaves the model-specific policy pluggable.
class PlaceholderAgent:
    def act(self, obs, info):
        raise RuntimeError(
            "Connect a policy/model to PlaceholderAgent.act(). "
            "The FAILFORGE environment, sampling, evaluation, and verifier loop is ready."
        )

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--episodes",type=int,default=100)
    ap.add_argument("--seed",type=int,default=0)
    ap.add_argument("--out",default="results/miniwob_failforge.csv")
    args=ap.parse_args()

    ok, err = check_browsergym()
    if not ok:
        print("BrowserGym unavailable:", err, file=sys.stderr)
        sys.exit(2)

    tasks=list_miniwob_tasks()
    sampler=AdaptiveFailureSampler(tasks, seed=args.seed)
    agent=PlaceholderAgent()
    classifier=FailureClassifier()
    verifier=TrajectoryVerifier()
    rows=[]

    for ep in range(args.episodes):
        task=sampler.sample()
        env=make_env(task,args.seed+ep)
        try:
            r=run_episode(env,agent,task,classifier=classifier,verifier=verifier)
        finally:
            env.close()
        sev=max([f.severity for f in r.failures],default=0.0)
        sampler.update(task,r.success,sev)
        rows.append({
            "episode":ep,"task":task,"success":int(r.success),
            "reward":r.total_reward,"steps":r.steps,
            "verifier_score":r.verifier_score,
            "shortcut":int(r.shortcut_flag),
            "failures":"|".join(sorted({f.kind for f in r.failures}))
        })

    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    with out.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)

if __name__=="__main__":
    main()
