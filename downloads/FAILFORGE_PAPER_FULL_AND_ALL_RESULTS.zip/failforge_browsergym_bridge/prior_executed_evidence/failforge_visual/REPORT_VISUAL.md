# FAILFORGE Visual Computer-Use Extension — Experimental Report

## Status

This package contains a fully executed **controlled visual synthetic computer-use benchmark**.
It is **not** a claim of OSWorld/OSWorld 2.0/WeaveBench public-benchmark SOTA.
Its purpose is to test the proposed mechanism under reproducible visual interaction,
OOD shifts, long horizons, shortcut opportunities, and failure-conditioned training.

## Environment

Each observation is a procedurally rendered 32x32 RGB desktop-like interaction screen
partitioned into 16 spatial action regions. The environment contains eight semantic widget
types and a multimodal goal token. The action space contains 16 spatial clicks plus VERIFY
and DISMISS.

Task states include:
- visual grounding;
- verification;
- modal interruption / dismissal;
- shortcut traps;
- randomized distractor density;
- position jitter;
- visual noise;
- occlusion;
- grayscale/theme shift;
- combined OOD transformations.

All screenshots, labels, rewards, and transitions are generated locally. No external model API
or proprietary model output was used.

## Training

Pure sparse reward optimization from random initialization collapsed toward easy global actions
(VERIFY/DISMISS) instead of learning visual grounding. This negative result motivated a practical
two-stage recipe:

1. **Visual-grounding warm start** on procedurally generated screenshots.
2. **Reward-based synthetic fine-tuning** under either uniform factor sampling or
   failure-conditioned hard-example mining.

FAILFORGE-HardMine samples a larger counterfactual candidate pool, evaluates the current policy,
selects observations on which the correct action has lowest probability, and mixes those failure
examples with random replay/exploration before each policy update.

## Main visual OOD result — 4 seeds

Per-seed combined OOD accuracy:

|   seed |   FAILFORGE-HardMine |   UniformFactor-RL |
|-------:|---------------------:|-------------------:|
|      0 |                0.495 |              0.435 |
|      1 |                0.484 |              0.382 |
|      2 |                0.57  |              0.525 |
|      3 |                0.419 |              0.391 |

Mean ± SD:

| method             |   mean |   std |
|:-------------------|-------:|------:|
| FAILFORGE-HardMine |  0.492 | 0.062 |
| UniformFactor-RL   |  0.433 | 0.066 |

Paired FAILFORGE-HardMine − UniformFactor-RL improvement:
- **Mean difference: 5.89 percentage points**
- **4/4 seeds positive**
- Paired t-test: **p=0.0334**
- Paired effect size: **Cohen dz=1.869**

This is the strongest current evidence for the visual failure-conditioned curriculum.

## OOD interpretation

FAILFORGE-HardMine improves not only held-out combined OOD but also IID and individual perturbation
accuracy in this suite. The strongest gain is not attributable to merely adding perturbations:
UniformFactor-RL trains on the same factor pool, while FAILFORGE changes which synthetic
experiences receive updates based on current failures.

## Verifier / reward-hacking stress test — 4 seeds

| variant     |   ('genuine_accuracy', 'mean') |   ('genuine_accuracy', 'std') |   ('shortcut_rate', 'mean') |   ('shortcut_rate', 'std') |
|:------------|-------------------------------:|------------------------------:|----------------------------:|---------------------------:|
| full        |                          0.809 |                         0.072 |                       0.001 |                      0.001 |
| no_verifier |                          0.578 |                         0.074 |                       0.274 |                      0.053 |

Under a hack-heavy training distribution, removing trajectory-aware reward correction increases
mean shortcut selection from approximately **0.1%**
to **27.4%**, while genuine task accuracy
falls from **80.9%**
to **57.8%**.

This visual experiment independently reproduces the central reward-hacking pathology seen in the
earlier symbolic benchmark.

## Long-horizon scaling — 4 seeds

|   horizon |   checkpoint_accuracy |   exact_completion |   ge80_completion |
|----------:|----------------------:|-------------------:|------------------:|
|         4 |                 0.46  |              0.047 |             0.047 |
|         8 |                 0.458 |              0.006 |             0.019 |
|        16 |                 0.461 |              0     |             0.007 |
|        32 |                 0.461 |              0     |             0.001 |
|        64 |                 0.463 |              0     |             0     |
|       128 |                 0.463 |              0     |             0     |

The policy's local/checkpoint accuracy remains roughly stable across horizon, while exact
completion rapidly collapses. At horizon 16 and above, exact completion is essentially zero in
this difficult combined-OOD setting. This isolates compounding action error as a distinct
long-horizon failure mechanism.

## Hard-mining ablation — 3 seeds

| variant   |   mean |   std |
|:----------|-------:|------:|
| hard100   |  0.364 | 0.069 |
| hard50    |  0.36  | 0.015 |
| hard75    |  0.328 | 0.051 |
| uniform   |  0.332 | 0.067 |

The hard-example mixture is non-monotonic. In this shorter ablation:
- 100% hard and 50% hard both outperform the corresponding uniform baseline on average;
- 75% hard is not consistently optimal.

Therefore the supported claim is **not** that a fixed hard-example ratio is universally best.
The supported claim is that failure-conditioned selection can improve robustness, while the
exploration/failure mixture remains a hyperparameter that requires calibration.

## Negative results retained

1. Pure sparse visual RL from scratch collapses toward easy action modes.
2. Early task-type-only failure reweighting does **not** reliably outperform uniform synthetic RL.
3. Failure conditioning becomes effective only after moving to **example-level visual hard mining**.
4. Hard-example ratio is non-monotonic.
5. Long-horizon exact completion remains poor even after local visual competence improves.

These results are retained because they directly constrain the scientific claim.

## Supported paper claim

> Synthetic computer-use training becomes more effective when failures select the next visual
> experiences, but failure conditioning must operate at the environment/example level rather than
> only reweighting broad task categories. Trajectory-aware reward correction is separately
> necessary to prevent shortcut exploitation, and improvements in local visual competence do not
> eliminate long-horizon compounding error.

## Relation to public CUA benchmarks

OSWorld 2.0 and WeaveBench motivate the same unsolved phenomena—long-horizon execution,
hidden/dynamic state, verification, and trajectory-aware auditing—but this package does not report
scores on those benchmarks. A public-benchmark bridge is the next external-validation step.

## Files

- `hardmine_all.csv` — main 4-seed uniform-vs-failure-conditioned visual experiment
- `visual_ood_summary.csv` — aggregated visual results
- `main_visual_sweep.csv` — earlier task-type reweighting experiment / negative result
- `verifier_stress.csv` — visual shortcut-reward stress test
- `long_horizon.csv` — long-horizon evaluation
- `ablation_all.csv` — hard-example-mixture ablation
- `failforge_visual_reproduce.py` — compact reproduction scaffold
- `visual_benchmark_samples.png` — example generated screens
- paper-ready plots (`*.png`)
