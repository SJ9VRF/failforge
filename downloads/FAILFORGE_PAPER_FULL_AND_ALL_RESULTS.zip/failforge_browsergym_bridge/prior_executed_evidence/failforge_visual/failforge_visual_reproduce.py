
"""
FAILFORGE Visual Synthetic Computer-Use Benchmark (compact reproduction)
Core ingredients used in the reported experiment:
- 32x32 procedural screenshot renderer on a 4x4 interaction grid
- 8 visual widget types + multimodal goal token
- normal / verify / popup / shortcut-hack states
- visual shifts: noise, position shift, occlusion, grayscale, combined
- visual grounding warm-start
- reward-based policy fine-tuning
- uniform-factor baseline
- failure-conditioned online hard-example mining
- trajectory-aware vs outcome-only reward stress test

The full raw results accompanying this script are the source of the paper tables.
"""
import math, copy, numpy as np, torch
import torch.nn as nn
import torch.nn.functional as F

NTYPE, NACT = 8, 18
VERIFY, DISMISS = 16, 17

class GridPolicy(nn.Module):
    def __init__(self, emb=24):
        super().__init__()
        self.cell_enc = nn.Sequential(
            nn.Linear(3*8*8,64), nn.ReLU(),
            nn.Linear(64,emb), nn.ReLU()
        )
        self.instr_emb = nn.Linear(NTYPE,emb,bias=False)
        self.global_enc = nn.Sequential(
            nn.Linear(3*32*32,64), nn.ReLU(),
            nn.Linear(64,2)
        )
        self.cell_bias = nn.Parameter(torch.zeros(16))

    def forward(self, x, instr):
        b=x.size(0)
        cells=x.view(b,3,4,8,4,8).permute(0,2,4,1,3,5).reshape(b,16,-1)
        ce=self.cell_enc(cells)
        ie=self.instr_emb(instr).unsqueeze(1)
        click=(ce*ie).sum(-1)/math.sqrt(ce.size(-1))+self.cell_bias
        global_actions=self.global_enc(x.flatten(1))
        return torch.cat([click,global_actions],dim=1)

def reward_objective(logits, rewards, entropy_coef=0.002):
    p=F.softmax(logits,dim=1)
    expected=(p*rewards).sum(dim=1)
    entropy=-(p*p.clamp_min(1e-8).log()).sum(dim=1)
    return -(expected + entropy_coef*entropy).mean()

def select_failure_conditioned_batch(model, x, instr, correct, batch_size, hard_fraction=.75):
    """Select low-correct-action-probability observations, mixed with random replay."""
    with torch.no_grad():
        p_correct=F.softmax(model(x,instr),1)[torch.arange(len(x)),correct]
    k=int(batch_size*hard_fraction)
    hard=torch.topk(-p_correct,k).indices
    random=torch.randperm(len(x))[:batch_size-k]
    return torch.cat([hard,random])

# See REPORT_VISUAL.md for exact experimental design and raw CSVs for all results.
