# FAILFORGE Experimental Report

## Scope
Controlled procedural computer-use RL benchmark. This is a mechanistic synthetic benchmark, not OSWorld/WeaveBench and not a claim of public-benchmark SOTA.

## Methods
Sparse RL; shaped RL; uniform synthetic RL; fixed curriculum; failure-conditioned frontier curriculum; replay mixtures; adaptive FAILFORGE mixing broad exploration + replay + failure-frontier training.

## Main controlled result
Adaptive FAILFORGE, 8 seeds:
| scenario   |   checkpoint |    sd |   highcomp |   verify |   recovery |   shortcut |
|:-----------|-------------:|------:|-----------:|---------:|-----------:|-----------:|
| combined   |        0.691 | 0.084 |      0.154 |    0.727 |      0.694 |          0 |
| dynamic    |        0.692 | 0.084 |      0.182 |    0.726 |      0.702 |          0 |
| hack       |        0.687 | 0.083 |      0.165 |    0.711 |      0.701 |          0 |
| iid        |        0.705 | 0.066 |      0.294 |    0.625 |      0.76  |          0 |
| long       |        0.693 | 0.077 |      0.133 |    0.672 |      0.729 |          0 |

## Replay sweep
|   lambda_ | scenario   |   checkpoint |   highcomp |   verify |   recovery |
|----------:|:-----------|-------------:|-----------:|---------:|-----------:|
|      0    | combined   |        0.676 |      0.015 |    0.723 |      0.635 |
|      0    | iid        |        0.754 |      0.413 |    0.815 |      0.791 |
|      0.1  | combined   |        0.652 |      0.007 |    0.695 |      0.622 |
|      0.1  | iid        |        0.71  |      0.304 |    0.735 |      0.748 |
|      0.25 | combined   |        0.651 |      0.008 |    0.694 |      0.622 |
|      0.25 | iid        |        0.711 |      0.287 |    0.742 |      0.75  |
|      0.4  | combined   |        0.651 |      0.008 |    0.694 |      0.622 |
|      0.4  | iid        |        0.711 |      0.287 |    0.742 |      0.75  |
|      0.6  | combined   |        0.706 |      0.137 |    0.747 |      0.69  |
|      0.6  | iid        |        0.749 |      0.391 |    0.757 |      0.792 |
|      0.8  | combined   |        0.627 |      0     |    0.667 |      0.612 |
|      0.8  | iid        |        0.669 |      0.179 |    0.655 |      0.724 |

## Horizon scaling
|   horizon |   checkpoint |   highcomp |   exact |   verify |   recovery |
|----------:|-------------:|-----------:|--------:|---------:|-----------:|
|         8 |        0.705 |      0.257 |   0.072 |    0.753 |      0.684 |
|        16 |        0.708 |      0.302 |   0.008 |    0.754 |      0.689 |
|        32 |        0.704 |      0.2   |   0     |    0.743 |      0.684 |
|        64 |        0.708 |      0.14  |   0     |    0.753 |      0.693 |
|        96 |        0.709 |      0.168 |   0     |    0.746 |      0.688 |
|       128 |        0.707 |      0.145 |   0     |    0.749 |      0.689 |

## Training budget
|   train_steps |   approx_train_episodes |   checkpoint |   highcomp |   verify |   recovery |
|--------------:|------------------------:|-------------:|-----------:|---------:|-----------:|
|            75 |                    2400 |        0.337 |      0     |    0.356 |      0.361 |
|           150 |                    4800 |        0.46  |      0     |    0.465 |      0.484 |
|           300 |                    9600 |        0.71  |      0.131 |    0.75  |      0.696 |
|           500 |                   16000 |        0.71  |      0.131 |    0.75  |      0.696 |

## Ablations
| variant            | scenario   |   checkpoint |   highcomp |   verify |   recovery |   shortcut |
|:-------------------|:-----------|-------------:|-----------:|---------:|-----------:|-----------:|
| full               | combined   |        0.653 |      0.015 |    0.688 |      0.629 |      0     |
| full               | hack       |        0.665 |      0.092 |    0.727 |      0.651 |      0     |
| no_antihack_target | combined   |        0.684 |      0.029 |    0.729 |      0.658 |      0     |
| no_antihack_target | hack       |        0.695 |      0.135 |    0.764 |      0.677 |      0     |
| no_recover_target  | combined   |        0.659 |      0.015 |    0.695 |      0.629 |      0     |
| no_recover_target  | hack       |        0.67  |      0.096 |    0.736 |      0.651 |      0     |
| no_state_target    | combined   |        0.659 |      0.015 |    0.696 |      0.629 |      0     |
| no_state_target    | hack       |        0.672 |      0.096 |    0.741 |      0.651 |      0     |
| no_verifier        | combined   |        0.41  |      0     |    0.38  |      0.403 |      0.466 |
| no_verifier        | hack       |        0.127 |      0     |    0.147 |      0.102 |      0.721 |
| no_verify_target   | combined   |        0.653 |      0.015 |    0.688 |      0.629 |      0     |
| no_verify_target   | hack       |        0.665 |      0.092 |    0.727 |      0.651 |      0     |

## Statistical comparison on combined OOD (8 paired seeds)
Adaptive FAILFORGE vs fixed curriculum: +10.85 percentage points checkpoint accuracy, paired t-test p=0.048, Cohen dz=0.846.
Adaptive FAILFORGE vs uniform synthetic: +1.70 points, p=0.771 (not significant).
Adaptive FAILFORGE vs failure-only: +5.29 points, p=0.199 (not significant).

## Key negative result
Failure-only curriculum is not reliably better than broad uniform synthetic training. The final method therefore retains broad exploration and replay rather than exclusively sampling failures.

## Verifier ablation
Removing the verifier causes severe shortcut exploitation: on the hack stress test shortcut rate rises to about 72.1% and genuine checkpoint accuracy falls to about 12.7%. This is the strongest mechanistic result in the current controlled suite.

## Interpretation
The current evidence supports:
1. trajectory-aware/verifier-corrected reward is essential under shortcut opportunities;
2. synthetic experience scale produces a steep learning transition around 9.6k training episodes in this setup;
3. long-horizon exact completion collapses even when checkpoint accuracy stays stable, illustrating compounding-error behavior;
4. replay has a non-monotonic effect; neither no replay nor maximal replay is universally optimal;
5. adaptive failure targeting improves over fixed curriculum, but does not yet significantly beat a strong uniform-synthetic baseline.

## What is not yet supported
- No claim of OSWorld, OSWorld2.0, WeaveBench, or real-desktop SOTA.
- No claim that the current state-tracking factor constitutes true recurrent memory; this controlled simulator exposes a state-related context variable rather than requiring a recurrent visual-memory policy.
- No frontier-model fine-tuning result.
