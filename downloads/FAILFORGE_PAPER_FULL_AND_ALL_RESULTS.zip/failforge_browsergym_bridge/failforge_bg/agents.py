from typing import Any

class Agent:
    def act(self, obs: Any, info: dict) -> str:
        raise NotImplementedError

class RandomActionAgent(Agent):
    """Debug-only baseline. For real BrowserGym runs use a model-backed Agent."""
    def __init__(self, action_space_fn, seed=0):
        import random
        self.action_space_fn = action_space_fn
        self.rng = random.Random(seed)

    def act(self, obs, info):
        actions = list(self.action_space_fn(obs, info))
        if not actions:
            return "noop()"
        return self.rng.choice(actions)

class ScriptedInfoAgent(Agent):
    """Unit-test oracle that reads a mock's expected action from info."""
    def act(self, obs, info):
        return info.get("expected_action", "noop()")
