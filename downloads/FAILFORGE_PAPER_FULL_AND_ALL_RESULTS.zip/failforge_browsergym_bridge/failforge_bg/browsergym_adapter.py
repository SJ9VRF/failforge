"""BrowserGym/MiniWoB adapter.

Requires:
    pip install browsergym-miniwob
    playwright install chromium
and a valid MINIWOB_URL per BrowserGym's MiniWoB setup instructions.
"""

def check_browsergym():
    try:
        import gymnasium as gym
        import browsergym.miniwob
        return True, None
    except Exception as e:
        return False, repr(e)

def list_miniwob_tasks():
    import gymnasium as gym
    import browsergym.miniwob  # registers envs
    return sorted(i for i in gym.envs.registry.keys() if i.startswith("browsergym/miniwob"))

def make_env(task_id: str, seed: int = 0):
    import gymnasium as gym
    import browsergym.miniwob
    env_id = task_id if task_id.startswith("browsergym/") else f"browsergym/miniwob.{task_id}"
    # BrowserGym tasks expose seed through reset; wrapper handles fixed reset seed.
    env = gym.make(env_id)
    return SeededResetWrapper(env, seed)

class SeededResetWrapper:
    def __init__(self, env, seed):
        self.env, self.seed = env, seed
    def reset(self):
        return self.env.reset(seed=self.seed)
    def step(self, action):
        return self.env.step(action)
    def close(self):
        return self.env.close()
