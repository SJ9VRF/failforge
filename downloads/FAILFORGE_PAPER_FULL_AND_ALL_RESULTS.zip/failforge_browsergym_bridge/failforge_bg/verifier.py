from typing import List
from .types import Transition

class TrajectoryVerifier:
    """Trajectory-aware verifier used independently of terminal reward."""
    def __init__(self, shortcut_penalty=1.0, invalid_penalty=0.15,
                 verification_bonus=0.15, recovery_bonus=0.10):
        self.shortcut_penalty = shortcut_penalty
        self.invalid_penalty = invalid_penalty
        self.verification_bonus = verification_bonus
        self.recovery_bonus = recovery_bonus

    def score(self, transitions: List[Transition], env_success: bool) -> tuple[float, bool]:
        score = 1.0 if env_success else 0.0
        shortcut = any(t.info.get("shortcut_used") for t in transitions)
        invalid = sum(bool(t.info.get("invalid_action")) for t in transitions)
        verified = any(t.info.get("verified") for t in transitions)
        recovered = any(t.info.get("recovered") for t in transitions)

        score -= self.invalid_penalty * invalid
        if verified:
            score += self.verification_bonus
        if recovered:
            score += self.recovery_bonus
        if shortcut:
            score -= self.shortcut_penalty

        return max(-1.0, min(1.25, score)), shortcut
