from typing import Callable, Dict, Iterable, List
from .types import Transition, EpisodeResult
from .failure import FailureClassifier
from .verifier import TrajectoryVerifier

def run_episode(env, agent, task_id: str, max_steps=40,
                classifier=None, verifier=None) -> EpisodeResult:
    classifier = classifier or FailureClassifier()
    verifier = verifier or TrajectoryVerifier()

    obs, info = env.reset()
    transitions = []
    total_reward = 0.0
    success = False

    for _ in range(max_steps):
        action = agent.act(obs, info)
        next_obs, reward, terminated, truncated, next_info = env.step(action)
        merged = dict(next_info or {})
        # preserve action-selection annotations if adapter supplies them in prior info
        for k in ("expected_action", "verification_required", "popup_present"):
            if k in info and k not in merged:
                merged[k] = info[k]
        transitions.append(Transition(obs, action, float(reward), bool(terminated), bool(truncated), merged))
        total_reward += float(reward)
        obs, info = next_obs, next_info
        if terminated or truncated:
            success = bool(next_info.get("success", reward > 0))
            break

    failures = classifier.classify(task_id, transitions, success)
    vscore, shortcut = verifier.score(transitions, success)
    return EpisodeResult(task_id, success, total_reward, len(transitions),
                         transitions, failures, vscore, shortcut)

def evaluate_tasks(env_factory: Callable[[str, int], object], agent_factory: Callable[[int], object],
                   task_ids: Iterable[str], seeds=(0,1,2,3), max_steps=40):
    rows = []
    for seed in seeds:
        agent = agent_factory(seed)
        for task_id in task_ids:
            env = env_factory(task_id, seed)
            try:
                result = run_episode(env, agent, task_id, max_steps=max_steps)
                rows.append({
                    "seed": seed,
                    "task_id": task_id,
                    "success": int(result.success),
                    "reward": result.total_reward,
                    "steps": result.steps,
                    "verifier_score": result.verifier_score,
                    "shortcut": int(result.shortcut_flag),
                    "failure_kinds": "|".join(sorted({f.kind for f in result.failures})),
                })
            finally:
                if hasattr(env, "close"):
                    env.close()
    return rows
