from typing import Any, Dict, List
from .types import FailureEvent, Transition

class FailureClassifier:
    """Mechanistic failure taxonomy for browser/computer-use trajectories.

    The classifier intentionally uses only trajectory evidence exposed by the
    environment/agent adapter. This makes it usable with BrowserGym, MiniWoB,
    mocks, and future OSWorld adapters.
    """
    def classify(self, task_id: str, transitions: List[Transition], success: bool) -> List[FailureEvent]:
        events: List[FailureEvent] = []
        if not transitions:
            return [FailureEvent(task_id, "empty_trajectory", 1.0, {})]

        # Explicit adapter annotations take precedence.
        explicit = []
        for i, t in enumerate(transitions):
            tags = t.info.get("failure_tags", []) or []
            for tag in tags:
                explicit.append(FailureEvent(task_id, str(tag), 1.0, {"step": i}))
        events.extend(explicit)

        # Generic diagnostics.
        invalid = sum(bool(t.info.get("invalid_action")) for t in transitions)
        repeated = 0
        for a, b in zip(transitions, transitions[1:]):
            if a.action == b.action:
                repeated += 1

        if invalid:
            events.append(FailureEvent(task_id, "grounding_or_action_invalid",
                                       min(1.0, invalid / max(1, len(transitions))),
                                       {"invalid_actions": invalid}))
        if repeated >= 3 and not success:
            events.append(FailureEvent(task_id, "loop_or_stagnation",
                                       min(1.0, repeated / max(1, len(transitions)-1)),
                                       {"repeated_adjacent_actions": repeated}))

        if any(t.info.get("popup_present") and not t.info.get("popup_handled", False) for t in transitions):
            events.append(FailureEvent(task_id, "recovery_failure", 1.0, {"source": "popup"}))

        if any(t.info.get("verification_required") for t in transitions):
            verified = any(t.info.get("verified") for t in transitions)
            if not verified:
                events.append(FailureEvent(task_id, "missing_verification", 1.0, {}))

        if any(t.info.get("shortcut_used") for t in transitions):
            events.append(FailureEvent(task_id, "reward_hacking", 1.0, {}))

        if not success and len(transitions) >= int(transitions[-1].info.get("horizon_threshold", 12)):
            events.append(FailureEvent(task_id, "long_horizon_drift", 1.0, {"steps": len(transitions)}))

        if not success and not events:
            events.append(FailureEvent(task_id, "unclassified_failure", 0.5, {}))
        return events
