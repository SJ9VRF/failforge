from collections import defaultdict
import math, random
from typing import Dict, Iterable, List, Optional

class AdaptiveFailureSampler:
    """FAILFORGE task sampler.

    Mixture:
      p = alpha * failure_frontier + beta * uniform + gamma * replay

    Failure frontier weight is an EMA of recent failure severity, while replay
    weight favors tasks with historical success to preserve competence.
    """
    def __init__(self, task_ids: Iterable[str], alpha=0.55, beta=0.30, gamma=0.15,
                 ema=0.85, seed=0):
        self.task_ids = list(task_ids)
        self.alpha, self.beta, self.gamma = alpha, beta, gamma
        s = alpha + beta + gamma
        if abs(s - 1.0) > 1e-6:
            raise ValueError("alpha+beta+gamma must equal 1")
        self.ema = ema
        self.rng = random.Random(seed)
        self.failure_score = defaultdict(lambda: 0.5)
        self.success_ema = defaultdict(lambda: 0.0)
        self.count = defaultdict(int)

    def update(self, task_id: str, success: bool, failure_severity: float):
        self.count[task_id] += 1
        self.failure_score[task_id] = (
            self.ema * self.failure_score[task_id] + (1-self.ema) * float(failure_severity)
        )
        self.success_ema[task_id] = (
            self.ema * self.success_ema[task_id] + (1-self.ema) * float(success)
        )

    def probabilities(self) -> Dict[str, float]:
        n = len(self.task_ids)
        if n == 0:
            return {}

        fail_raw = [max(1e-4, self.failure_score[t]) for t in self.task_ids]
        rep_raw = [max(1e-4, self.success_ema[t]) for t in self.task_ids]

        def norm(xs):
            s = sum(xs)
            return [x/s for x in xs] if s else [1/len(xs)] * len(xs)

        pf = norm(fail_raw)
        pr = norm(rep_raw)
        pu = [1/n]*n
        vals = [
            self.alpha*pf[i] + self.beta*pu[i] + self.gamma*pr[i]
            for i in range(n)
        ]
        z = sum(vals)
        return {t: vals[i]/z for i,t in enumerate(self.task_ids)}

    def sample(self) -> str:
        probs = self.probabilities()
        tasks = list(probs)
        return self.rng.choices(tasks, weights=[probs[t] for t in tasks], k=1)[0]
