from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class Transition:
    obs: Any
    action: str
    reward: float
    terminated: bool
    truncated: bool
    info: Dict[str, Any] = field(default_factory=dict)

@dataclass
class FailureEvent:
    task_id: str
    kind: str
    severity: float
    evidence: Dict[str, Any] = field(default_factory=dict)

@dataclass
class EpisodeResult:
    task_id: str
    success: bool
    total_reward: float
    steps: int
    transitions: List[Transition]
    failures: List[FailureEvent]
    verifier_score: float
    shortcut_flag: bool = False
