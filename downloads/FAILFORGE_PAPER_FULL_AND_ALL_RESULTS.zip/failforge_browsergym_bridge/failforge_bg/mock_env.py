import random

class MockMiniWoBEnv:
    """Deterministic-enough mock for testing the FAILFORGE loop without BrowserGym."""
    def __init__(self, task_id, seed=0):
        self.task_id = task_id
        self.rng = random.Random((hash(task_id) & 0xffff) + seed)
        self.t = 0
        self.horizon = 3 + self.rng.randint(0, 5)
        self.popup_step = 1 if "popup" in task_id else None
        self.verify = any(x in task_id for x in ("form", "login", "order", "calendar"))
    def reset(self, seed=None):
        self.t = 0
        info = {"expected_action": f"click({self.t})",
                "verification_required": self.verify,
                "popup_present": False}
        return {"task": self.task_id, "step": self.t}, info
    def step(self, action):
        expected = f"click({self.t})"
        invalid = action != expected
        self.t += 1
        popup_present = self.popup_step == self.t
        terminated = self.t >= self.horizon
        success = terminated and not invalid
        info = {
            "success": success,
            "invalid_action": invalid,
            "popup_present": popup_present,
            "popup_handled": not popup_present,
            "verified": self.verify and self.t >= self.horizon-1,
            "horizon_threshold": 6,
            "expected_action": f"click({self.t})",
        }
        reward = 1.0 if success else 0.0
        return {"task": self.task_id, "step": self.t}, reward, terminated, False, info
    def close(self): pass
