# FAILFORGE × BrowserGym/MiniWoB Bridge

This package bridges the FAILFORGE failure-conditioned synthetic-RL idea to the
public BrowserGym/MiniWoB interface.

## What is implemented

- BrowserGym/MiniWoB environment discovery and adapter.
- Task-family map aligned to computer-use failure modes.
- Failure taxonomy and trajectory failure classifier.
- Trajectory-aware verifier with shortcut/reward-hacking penalties.
- Adaptive mixture sampler:
  `failure frontier + uniform exploration + competence replay`.
- Seeded evaluation harness and CSV logging.
- Mock MiniWoB environment so the full control/data-flow can be tested without
  BrowserGym installed.
- Public-benchmark experiment protocol and task-family config.

## Runtime status in the ChatGPT execution environment

A real BrowserGym installation was attempted on 2026-08-26 with:

    python -m pip install browsergym-miniwob

The system package installer could not resolve PyPI because outbound DNS/network
access is disabled in the execution container. Therefore **no MiniWoB public
benchmark score is claimed in this package**.

This is an infrastructure limitation, not an algorithmic result.

## Setup in a networked environment

Per BrowserGym's official instructions:

    pip install browsergym-miniwob
    playwright install chromium

Then set up MiniWoB++ and `MINIWOB_URL` according to BrowserGym's MiniWoB setup.
The upstream BrowserGym Makefile currently pins MiniWoB++ commit
`7fd85d71a4b60325c6585396ec4f48377d049838` for reproducibility.

## Sanity test without BrowserGym

    PYTHONPATH=. python scripts/run_mock_bridge.py
    PYTHONPATH=. pytest -q tests

## Real MiniWoB environment discovery

    python -c "from failforge_bg.browsergym_adapter import list_miniwob_tasks; print('\n'.join(list_miniwob_tasks()))"

BrowserGym registers tasks with IDs such as:

    browsergym/miniwob.choose-list
    browsergym/miniwob.click-test
    browsergym/miniwob.form-sequence

## Scientific protocol

We recommend matched task/seed comparisons across:
1. uniform sampling,
2. failure-only sampling,
3. failure + exploration,
4. FAILFORGE failure + exploration + replay.

Report success, reward, steps, verifier score, shortcut rate, failure recurrence,
and paired statistical tests.

## Important integrity boundary

This package is **benchmark-ready**, but it does not fabricate BrowserGym scores.
The existing FAILFORGE symbolic and visual synthetic experiments remain the
executed evidence; MiniWoB scores must be generated where BrowserGym/Chromium
can actually run.
